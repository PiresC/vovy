module.exports = {
    INDORELAWAN_ORGANIZATION: 'indorelawan'
}