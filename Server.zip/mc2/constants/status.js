module.exports = {
    ERROR: {
        status: 500,
        message: 'internal server error'
    },
    SUCCESS: {
        status: 200,
        message: 'OK'
    }
}