module.exports = {
    INDORELAWAN_API: "https://indorelawan.org/api/activity/search-activities" 
}